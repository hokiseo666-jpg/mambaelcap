
(function () {
  const host = (typeof window !== 'undefined' && window.location && window.location.hostname) || '';
  let API_BASE = '';
  if (host === 'localhost' || host === '127.0.0.1') API_BASE = 'http://localhost:3000';
  else if (host.startsWith('staging.') || host.includes('staging')) API_BASE = 'https://staging.api.yourbrand.com';
  else if (host) API_BASE = 'https://api.yourbrand.com';
  window.AUTH_CONFIG = {
    API_BASE,
    ENDPOINTS: { login:'/api/auth/login', register:'/api/auth/register', otp:'/api/auth/otp/send' },
    REDIRECT_AFTER_LOGIN: '/dashboard',
    STORE_TOKEN_IN_LOCALSTORAGE: false,
    map: {
      loginRequest: ({ userid, password }) => ({ username: userid, password }),
      registerRequest: ({ userid, password, phone, otp }) => ({ username: userid, password, phone, otp }),
      otpRequest: (phoneE164) => ({ phone: phoneE164, purpose: 'register' }),
      loginResponse: (res) => ({ ok: res?.status==='success', message: res?.message || 'OK', token: res?.data?.token }),
      registerResponse: (res) => ({ ok: res?.status==='success', message: res?.message || 'OK' }),
      otpResponse: (res) => ({ ok: res?.status==='success', message: res?.message || 'OTP dikirim' }),
      errorMessage: (err) => { const b=err?.body||{}; return b.message || b.error || err?.message || 'Request gagal'; }
    }
  };
})();