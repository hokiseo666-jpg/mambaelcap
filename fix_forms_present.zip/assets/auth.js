
document.addEventListener('DOMContentLoaded', () => {
  const CFG = Object.assign({
    API_BASE: '',
    ENDPOINTS: { login:'/api/auth/login', register:'/api/auth/register', otp:'/api/auth/otp/send' },
    REDIRECT_AFTER_LOGIN: '/dashboard',
    REQUEST_TIMEOUT_MS: 15000,
    STORE_TOKEN_IN_LOCALSTORAGE: false,
    map: {}
  }, (window.AUTH_CONFIG || {}));

  const map = Object.assign({
    loginRequest: ({ userid, password }) => ({ username: userid, password }),
    loginResponse: (res) => ({ ok: !!(res?.ok ?? res?.success ?? res?.token), message: res?.message || res?.error || 'OK', token: res?.data?.token || res?.token }),
    registerRequest: ({ userid, password, phone, otp }) => ({ username: userid, password, phone, otp }),
    registerResponse: (res) => ({ ok: !!(res?.ok ?? res?.success ?? res?.id), message: res?.message || res?.error || 'OK' }),
    otpRequest: (phoneE164) => ({ phone: phoneE164, purpose: 'register' }),
    otpResponse: (res) => ({ ok: !!(res?.ok ?? res?.success ?? true), message: res?.message || 'OTP dikirim' }),
    errorMessage: (err) => (err?.body?.message || err?.body?.error || err?.message || 'Request failed')
  }, CFG.map || {});

  const CSRF_SELECTOR = 'meta[name="csrf-token"]';
  const getCSRF = () => (document.querySelector(CSRF_SELECTOR)?.content || '');
  const $ = sel => document.querySelector(sel);
  const createEl = (tag, cls, html) => { const el=document.createElement(tag); if(cls) el.className=cls; if(html) el.innerHTML=html; return el; };
  const toast = (msg, type='info', timeout=3200) => { const t=createEl('div',`toast ${type}`,msg); Object.assign(t.style,{position:'fixed',left:'50%',transform:'translateX(-50%)',bottom:'22px',background:'rgba(0,0,0,.84)',color:'#fff',padding:'10px 14px',borderRadius:'10px',zIndex:9999,boxShadow:'0 10px 30px rgba(0,0,0,.4)',fontSize:'13px'}); document.body.appendChild(t); setTimeout(()=>t.remove(),timeout); };
  const fieldError = (input, msg) => { input.setCustomValidity(msg||''); input.reportValidity(); };

  function normalizeIDPhone(v){ if(!v) return ''; let s=v.trim().replace(/[^\d+]/g,''); if(s.startsWith('+')) s=s.slice(1); if(s.startsWith('0')) s='62'+s.slice(1); else if(!s.startsWith('62') && s.startsWith('8')) s='62'+s; s=s.replace(/^62+0+/, '62'); return '+'+s; }
  const isValidIDMobile = (e164) => /^\+628\d{8,11}$/.test(e164);

  async function apiPost(path, data, opt={}){
    const ctrl = new AbortController(); const to = setTimeout(()=>ctrl.abort(), CFG.REQUEST_TIMEOUT_MS);
    try{
      const res = await fetch(CFG.API_BASE + path, { method:'POST', headers:{'Content-Type':'application/json','X-CSRF-Token':getCSRF(),...(opt.headers||{})}, credentials: opt.credentials ?? 'include', body: JSON.stringify(data||{}), signal: ctrl.signal });
      const isJSON=(res.headers.get('content-type')||'').includes('application/json'); const body=isJSON?await res.json().catch(()=>({})):await res.text();
      if(!res.ok){ const err=new Error((body&&(body.error||body.message))||res.statusText||'Request failed'); err.status=res.status; err.body=body; throw err; }
      return body;
    } finally { clearTimeout(to); }
  }

  const card=$('.auth-card'); if(!card) return;
  const title=card.querySelector('.auth-title'); const formLogin=$('#form-login'); const formReg=$('#form-register'); const toLogin=card.querySelectorAll('[data-to="login"]'); const toReg=card.querySelectorAll('[data-to="register"]'); const otpBtn=$('#btn-otp'); const phoneInput=formReg?.querySelector('input[name="phone"]');

  function setMode(m){ card.dataset.mode=m; title.textContent=(m==='login'?'Login':'Daftar'); formLogin.hidden=(m!=='login'); formReg.hidden=(m!=='register'); }
  toLogin.forEach(a=>a.addEventListener('click',e=>{e.preventDefault(); setMode('login');})); toReg.forEach(a=>a.addEventListener('click',e=>{e.preventDefault(); setMode('register');})); setMode(card.dataset.mode||'login');

  if(phoneInput){ const ensureMask=()=>{ if(!phoneInput.value.trim()) phoneInput.value='+62'; if(!phoneInput.value.startsWith('+62')) phoneInput.value=normalizeIDPhone(phoneInput.value); }; phoneInput.addEventListener('focus', ensureMask); phoneInput.addEventListener('blur', ()=>{ const e164=normalizeIDPhone(phoneInput.value); phoneInput.value=(e164!=='+'?e164:'+62'); phoneInput.setCustomValidity(''); }); phoneInput.addEventListener('input', ()=> phoneInput.setCustomValidity('')); }

  if(otpBtn){ let cd=0,t=null; const upd=()=>{ if(cd>0){ otpBtn.textContent=`Kirim OTP (${String(cd).padStart(2,'0')})`; otpBtn.disabled=true; } else { otpBtn.textContent='Kirim OTP'; otpBtn.disabled=false; } }; const start=(s=60)=>{ cd=s; upd(); t=setInterval(()=>{ cd--; upd(); if(cd<=0){ clearInterval(t); t=null; } },1000); };
    otpBtn.addEventListener('click', async (e)=>{ e.preventDefault(); if(cd>0) return; if(!phoneInput) return; const e164=normalizeIDPhone(phoneInput.value); if(!isValidIDMobile(e164)) return fieldError(phoneInput,'Nomor Indonesia tidak valid. Gunakan format +628xxxxxxxxx'); phoneInput.value=e164; fieldError(phoneInput,''); try{ start(60); const resp=await apiPost(CFG.ENDPOINTS.otp, map.otpRequest(e164)); const out=map.otpResponse(resp); if(!out.ok) throw new Error(out.message||'Gagal mengirim OTP'); toast(out.message||'OTP dikirim','success'); }catch(err){ cd=0; upd(); toast(map.errorMessage(err),'error'); } });
  }

  formLogin?.addEventListener('submit', async (e)=>{ e.preventDefault(); const btn=formLogin.querySelector('[type="submit"]'); const data=new FormData(formLogin); const userid=data.get('userid'); const password=data.get('password'); if(!userid) return fieldError(formLogin.userid,'User ID wajib diisi'); if(!password) return fieldError(formLogin.password,'Password wajib diisi'); formLogin.userid.setCustomValidity(''); formLogin.password.setCustomValidity(''); btn.disabled=true; btn.textContent='Memproses...'; try{ const resp=await apiPost(CFG.ENDPOINTS.login, map.loginRequest({userid,password})); const out=map.loginResponse(resp); if(!out.ok) throw new Error(out.message||'Login gagal'); if(CFG.STORE_TOKEN_IN_LOCALSTORAGE && out.token){ try{ localStorage.setItem('auth_token', out.token); }catch{} } toast(out.message||'Login berhasil','success'); setTimeout(()=>location.assign(CFG.REDIRECT_AFTER_LOGIN), 600); }catch(err){ toast(map.errorMessage(err),'error'); }finally{ btn.disabled=false; btn.textContent='Masuk'; } });
  formReg?.addEventListener('submit', async (e)=>{ e.preventDefault(); const btn=formReg.querySelector('[type="submit"]'); const data=new FormData(formReg); const userid=data.get('userid'); const password=data.get('password'); const phone=normalizeIDPhone(data.get('phone')||''); const otp=data.get('otp'); if(!userid) return fieldError(formReg.userid,'User ID wajib diisi'); if(!password || password.length<6) return fieldError(formReg.password,'Password min. 6 karakter'); if(!phone || !isValidIDMobile(phone)) return fieldError(formReg.phone,'Nomor Indonesia tidak valid. Gunakan format +628xxxxxxxxx'); if(!otp) return fieldError(formReg.otp,'Kode OTP wajib diisi'); formReg.userid.setCustomValidity(''); formReg.password.setCustomValidity(''); formReg.phone.setCustomValidity(''); formReg.otp.setCustomValidity(''); formReg.phone.value=phone; btn.disabled=true; btn.textContent='Memproses...'; try{ const resp=await apiPost(CFG.ENDPOINTS.register, map.registerRequest({userid,password,phone,otp})); const out=map.registerResponse(resp); if(!out.ok) throw new Error(out.message||'Registrasi gagal'); toast(out.message||'Registrasi berhasil','success'); document.querySelector('[data-to="login"]').click(); }catch(err){ toast(map.errorMessage(err),'error'); }finally{ btn.disabled=false; btn.textContent='Daftar'; } });
});
